<?php

/**
 * LoginForm class.
 * LoginForm is the data structure for keeping
 * user login form data. It is used by the 'login' action of 'SiteController'.
 */
class holiday extends CActiveRecord
{
	public $name;
	public $holiday_date;
	public $holiday_type;
	public $active;

	public function tableName()
	{
		return 'hrm_holidays';
	}

	/**
	 * Declares the validation rules.
	 * The rules state that username and password are required,
	 * and password needs to be authenticated.
	 */
	public function rules()
	{
		return array(
			// name and holiday_date are required
			array('name, holiday_date', 'required'),
			// rememberMe needs to be a boolean
			array('active', 'boolean'),
			
			
		);
	}

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function getAllHolidays($limit,$display_length,$search,$column,$dir)
       {
       		
       		 $columns = array(0=>"name",1=>"holiday_date",2=>"holiday_type");
         
         if ($columns !='')
         	$orderby = "order by ".$columns[$column]." ".$dir;

       		if ($search!='')
       			$append = " and (name like '%$search%' or holiday_type like '%$search%')";
       		else
       			$append = '';

       		$getall = Yii::app()->db->createCommand("SELECT id,name,holiday_date,holiday_type from hrm_holidays where active = 'Y' $append $orderby limit $limit,$display_length ")->queryAll();
            return $getall;


       }

         public function getAllHolidays_Calendar($start_date,$end_date)
         {
          
      	$getall = Yii::app()->db->createCommand("SELECT id,name,holiday_date,holiday_type from hrm_holidays where active = 'Y' 
                     and holiday_date between '$start_date' and '$end_date'

                  ")->queryAll();
            return $getall;
      	
        }

        public function getAllLeaves($start_date,$end_date,$empnumber)
        {

           $session = new CHttpSession;
           $session->open();

           if (($session['user_role'] == 1 or $session['user_role'] == 2) and $empnumber>0)
             $append = " and a.emp_number  = '$empnumber' ";
          elseif ($session['user_role'] != 1)
             $append = " and a.emp_number  = ".$session['empnumber'];
           else
             $append = " and a.emp_number = '0' " ;


            $getall = Yii::app()->db->createCommand("SELECT b.id as userid,a.id,a.emp_number,a.start_date,a.end_date,a.approval from hrm_leave a 
              inner join hrm_user_master b on a.emp_number = b.emp_number where 
                      (a.start_date between '$start_date' and '$end_date' or a.end_date between '$start_date' and '$end_date') 
                        $append  and a.approval !='reject' and a.approval !='cancel' ")->queryAll();

           
            return $getall;
            
        }

        public function getWeekdays()
        {
           $session = new CHttpSession;
           $session->open();
          
             $getall = Yii::app()->db->createCommand("SELECT  week_days from hrm_leave_days Where
              emp_number = '{$session["empnumber"]}' ")->queryAll();
            return $getall;


        }

       public function getAllHolidays_cnt()
      {
      	$getall = Yii::app()->db->createCommand("SELECT id from hrm_holidays where active = 'Y' ")->queryAll();
            return count($getall);
      	
      }

      public function getAllHolidays_search_cnt($search)
      {
      	$getall = Yii::app()->db->createCommand("SELECT id from hrm_holidays where active = 'Y'
      		and (name like '%$search%' or holiday_type like '%$search%')")->queryAll();
            return count($getall);
      	
      }

      
 	
 	public function deleteHoliday($id)
      {
      	$getall = Yii::app()->db->createCommand("DELETE from hrm_holidays WHERE id = ".$id)->query();
            return count($getall);
      	
      }
       

	
}
