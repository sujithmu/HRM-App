$(document).ready(function(){
    
    $('#forgotpass').click(function(){


     $('#forgotpassform').show();
     $('#loginform').hide();
//loginform 
    });

     


     $('#btnsubmit').click(function(){
         
         $.post(baseurl+"/index.php?r=Loginregister/LoginValidation",{uemail:$('#uemail').val(),upw:$('#upw').val()}).done(function(data)
         {
             if (data!='success')
             {
                  $('#error_msg').html("Invalid username or password");
                 $('#error_msg').show();
                 
                 
             }
             else{
                 
                 location.href=baseurl+"/index.php";
             }
            
    });
    
    });


      $('#forgotbtn').click(function(){
         
         $.post(baseurl+"/index.php?r=Manageuser/Mailsend",{loginemail:$('#loginemail').val()}).done(function(data)
         {
             if (data!='success')
             {
                 $('#forgetalert').html("Invalid Email");
                 $('#forgetalert').show();
                 $('#forgetsuccess').hide();
                 
                 
             }else{

                  $('#forgetalert').hide();
                  $('#forgetsuccess').html("Please check your mail to get the login details");
                 $('#forgetsuccess').show();

             }
             
            
    });
    
    });
    
     $('#uemail,#upw').keypress(function(e)
    {
        if(e.which==13){
            
            $('#btnsubmit').trigger('click');
        }
        
    });
    
    });
    